# fluorCalc
Calculate Expected Count Rate in Fluorescence XAFS
