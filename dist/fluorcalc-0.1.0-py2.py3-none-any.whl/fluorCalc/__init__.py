__version__ = "0.1.0"
__author__ = 'Christian Geci'
__credits__ = 'University of Maine'

